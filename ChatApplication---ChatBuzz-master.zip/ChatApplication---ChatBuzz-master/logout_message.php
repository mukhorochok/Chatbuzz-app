<?php
header( "refresh:1; url=main_login.php" );
?>

<html>
<h4> You have succesfully loggged out! </h4>
</html>